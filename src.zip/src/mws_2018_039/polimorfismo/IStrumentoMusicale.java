package mws_2018_039.polimorfismo;

public interface IStrumentoMusicale {
    public void suona();
    public int dammiPrezzo( String nomeStrumento );
}
