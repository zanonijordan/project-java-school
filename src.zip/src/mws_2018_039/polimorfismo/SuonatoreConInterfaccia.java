package mws_2018_039.polimorfismo;

public class SuonatoreConInterfaccia {
    public void suonaStrumento( IStrumentoMusicale sm ){
        sm.suona();
    }
}
