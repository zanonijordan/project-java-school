package mws_2018_039.testwhile;

public class TestWhile2 {
    public static void main(String[] args) {
        int var = 4;
        while ( var < 10 ) {
            System.out.println("ciao");
            var = var + 1;
        }
        System.out.println("FINE");
    }
}
