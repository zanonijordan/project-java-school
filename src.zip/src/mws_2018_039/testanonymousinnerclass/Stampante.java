package mws_2018_039.testanonymousinnerclass;

public interface Stampante {
    void stampa( String txt );
}
