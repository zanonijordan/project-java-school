package mws_2018_039.testanonymousinnerclass;

public class MiaStampante implements Stampante {

    @Override
    public void stampa(String txt) {
        System.out.println("____"+txt);
    }
    
}
