package mws_2018_039.testswing;

public class Swing02 {
    public static void main(String[] args) {
        //MiaFinestra f1 = new MiaFinestra("App", true, "ciao");
        //MiaFinestra f2 = new MiaFinestra("Sottofinestra 1", false, "miao");
        //MiaFinestra f3 = new MiaFinestra("Sottofinestra 2", false, "bau");
        MiaFinestraPanel fp = new MiaFinestraPanel("Lele");
    }
}
