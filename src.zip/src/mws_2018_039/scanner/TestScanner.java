package mws_2018_039.scanner;

import java.util.Scanner;

public class TestScanner {
    public static void main(String[] args) {
        Scanner sc = new Scanner( System.in );
        
        System.out.println("input:");
       String val3 = sc.next();
        System.out.println("val3: "+ val3);
        
    }
}
