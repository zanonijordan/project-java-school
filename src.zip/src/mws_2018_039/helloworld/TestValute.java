package mws_2018_039.helloworld;

public class TestValute {
    
    public static float convertiInEuro( float e ){
        return e * 1.23F;
    }
    
    public static float convertiInDollari( float d ){
        return d * 0.82F;
    }
}
