package mws_2018_039.helloworld;

public class SecondClass {
    public static String messaggio = "Cioa cioa";
    
    public static String dammiSecondoMessaggio(){
        return "secondo ciao ***";
    }
    
}
