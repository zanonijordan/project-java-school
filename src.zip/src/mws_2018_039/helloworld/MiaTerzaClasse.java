package mws_2018_039.helloworld;

public class MiaTerzaClasse {
    public static int dammiNumeroGiorni( int parametro ){
        System.out.println( "...sto calcolando i giorni" );
        return parametro + 10;
    }
    
    
    public static int stampaPrezzo( float p ){
        System.out.println( "L'importo è: "+ p +" €" );
        
        return 5;
    }
}
