package mws_2018_039.testparametri;

public class Studente {
    public static String nome;
    public static String cognome;
    public static String matricola;
    public static int eta;
}
