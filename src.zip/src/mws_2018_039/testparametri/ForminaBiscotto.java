package mws_2018_039.testparametri;

public class ForminaBiscotto {
    public static String forma;     // COSTANTI
    
    String gusto;            // ATTRIBUTI
}
