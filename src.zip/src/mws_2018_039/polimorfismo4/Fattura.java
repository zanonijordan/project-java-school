package mws_2018_039.polimorfismo4;

public class Fattura implements Stampabile{

    @Override
    public void stampa() {
        System.out.println("stampo fattura");
    }
    
}
