package mws_2018_039.polimorfismo4;

public class CartaDiIdentita implements Stampabile{
    public void stampa(){
        
    }
}
