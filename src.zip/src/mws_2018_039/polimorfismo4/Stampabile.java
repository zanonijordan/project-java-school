package mws_2018_039.polimorfismo4;

public interface Stampabile {
    public void stampa();
}
