package mws_2018_039.polimorfismo4;

public class Stampante {
    public void stampaDoc( Stampabile s ){
        s.stampa();
    }
}
