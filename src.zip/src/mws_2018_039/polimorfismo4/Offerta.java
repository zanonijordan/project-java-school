package mws_2018_039.polimorfismo4;

public class Offerta implements Stampabile{
    
    @Override
    public void stampa() {
        System.out.println("stampo offerta");
    }

}
