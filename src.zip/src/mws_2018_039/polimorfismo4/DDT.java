package mws_2018_039.polimorfismo4;

public class DDT implements Stampabile{

    @Override
    public void stampa() {
        System.out.println("...stampo ddt");
    }
    
}
