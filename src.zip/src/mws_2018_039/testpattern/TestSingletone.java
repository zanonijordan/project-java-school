package mws_2018_039.testpattern;

public class TestSingletone {
    public static void main(String[] args) {
        CiaoSingleton.getInstance().faiQualcosa();
        
        
        
        CiaoSingleton.getInstance().faiQualcosa();
    }
}
