package mws_2018_039.testistanze;

public class TestMain {
    public static void main(String[] args) {
        String s1 = new String();
        String s2 = new String();
        String s3 = new String();
        
        s1 = "Lele";
        s2 = "Ema";
        
        Persona p1 = new Persona();
        p1.cognome = "Rizo";
        p1.nome    = "Lele";
        p1.eta     = 21;
        
        Persona p2 = new Persona();
        p2.nome    = "Rizzzo";
        p2.nome    = "Manu";
        
        Persona p3 = new Persona();
    }
}