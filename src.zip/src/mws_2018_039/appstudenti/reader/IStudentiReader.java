package mws_2018_039.appstudenti.reader;

import mws_2018_039.appstudenti.dto.StudenteDTO;

public interface IStudentiReader {
    public StudenteDTO read();
}
