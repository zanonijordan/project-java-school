package mws_2018_039.appstudenti.reader;

import mws_2018_039.appstudenti.dto.StudenteDTO;

public class StudentiReaderSwing implements IStudentiReader{
    @Override
    public StudenteDTO read(){
        //TODO - la facciamo prox lessione
        return null;
    }
    
}
