package mws_2018_039.appstudenti.reader;

import mws_2018_039.appstudenti.dto.DocenteDTO;

public class DocentiReader extends Reader{
    public DocenteDTO read(){
        return null;
    }
}
