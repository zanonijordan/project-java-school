package mws_2018_039.appstudenti.dto;

public class DocenteDTO {
    
}
