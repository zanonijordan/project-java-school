package mws_2018_039.appstudenti.storage;

public class DocentiStorage {
}
