package mws_2018_039.arrayvsarraylist;

public class Appartamento {
    
}
