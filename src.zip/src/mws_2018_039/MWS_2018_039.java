package mws_2018_039;

import mws_2018_039.testpackage.PrimaClasse;

public class MWS_2018_039 {
    private static int eta;
    private static String nome;
    
    public static void main(String[] args) {
        System.out.println("Hello World!!");
        eta = 18;
        nome = "Lele";
        System.out.println(nome);
        PrimaClasse p;
        PrimaClasse.categoria = "Mammiferi";
        
        
        SecondaClasse s;
    }
    
    public static Studente dimmiChiVince(){
        Studente s = new Studente();
        
        return s;
    }
    
}
