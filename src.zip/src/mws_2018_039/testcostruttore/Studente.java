package mws_2018_039.testcostruttore;

public class Studente extends Persona{

    public Studente() {
    }
    
    public Studente( String nome ) {
        super("RZZMNL......");
        System.out.println("corstuisco studente: "+ nome);
    }
}
