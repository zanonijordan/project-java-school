package mws_2018_039.testcostruttore;

public class TestMain {
    public static void main(String[] args) {
        
        Studente eman  = new Studente("leleeeee");
        
        Integer i = new Integer(3);
        
        String st = new String();
        
        
        
    }
}
