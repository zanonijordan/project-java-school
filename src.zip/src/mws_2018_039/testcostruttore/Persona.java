package mws_2018_039.testcostruttore;

public class Persona {

    public Persona() {
        super();
        System.out.println("Creo una Persona");
    }
    public Persona(String cf) {
        super();
        System.out.println("Creo una Persona cf: "+ cf);
    }
}
