package mws_2018_039.testereditarieta2;

public class Suonatore {
    public void suonaStrumento( StrumentoMusicale s ){
        s.suona();
    }
}
