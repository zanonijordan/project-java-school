package mws_2018_039.testereditarieta2;

public class TestMain {
    public static void main(String[] args) {
        StrumentoMusicale sm = new StrumentoMusicale();
        
        Chitarra c = new Chitarra();
        c.suona();
    }
}
