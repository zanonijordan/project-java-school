package mws_2018_039.testwrapper;

public class Test {
    public static void main(String[] args) {
        byte b = 6;     Byte wb = new Byte(b);
        short s;    Short ws;
        int i = 7;      Integer wi;
        long l;     Long wl;
        
        float f;    Float wf;
        double d;   Double wd;
        
        boolean bb; Boolean wbb;
        char c;     Character wc;
        
        if( b<1 && i>4 ){
            
        }
    }
}
