package mws_2018_039.testcostruttore2;

public class Device {
    private String matricola;
    private String marca;

   

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getMarca() {
        return marca;
    }
    
    
}
