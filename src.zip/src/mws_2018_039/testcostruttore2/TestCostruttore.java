package mws_2018_039.testcostruttore2;

public class TestCostruttore {
    public static void main(String[] args) {
        StampanteFinta sf = new StampanteFinta();
        
        
        sf.stampa( "1111" );
        sf.stampa( "2222" );
        sf.stampa( "3333" );
        
    }
}
