package mws_2018_039.testpackage;

public class PrimaClasse {
    public static String categoria;
    public static String nome;
    public static int eta;
}
