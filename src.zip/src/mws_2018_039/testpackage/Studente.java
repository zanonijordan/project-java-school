package mws_2018_039.testpackage;

public class Studente {
    public static String aula;
}
