package mws_2018_039.array;

public class TestArray2 {
    public static void main(String[] args) {
        
        
    }
}
