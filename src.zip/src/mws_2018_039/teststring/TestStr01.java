package mws_2018_039.teststring;

public class TestStr01 {
    public static void main(String[] args) {
        String s = "ciao come stai?";
        System.out.println("--> "+ s.charAt( 3 ));
        System.out.println("--> "+ s.indexOf("s" ));
    }
}
