package mws_2018_039.incapsulamento2;


public class TestMain {
    public static void main(String[] args) {
        String nome = "lele.";
    }
    
    private static void st( Paziente p ){
        System.out.println("-->"+ p);
    }
    private static void st( int p ){
        System.out.println("-->"+ p);
    }
}
