package mws_2018_039.otherpkg;

public class OtherMain {
    public static void main(String[] args) {
        OtherClass oc = new OtherClass();
        
    }
}
