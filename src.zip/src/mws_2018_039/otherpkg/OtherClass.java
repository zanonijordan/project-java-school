package mws_2018_039.otherpkg;

import mws_2018_039.testereditarieta.Veicolo;

public class OtherClass extends Veicolo{
    
}
