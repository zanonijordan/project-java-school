/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mws_2018_039.testexception2;

/**
 *
 * @author Dr. Emanuele Rizzo @ ISNow Srl <lele@isnow.it>
 */
public class IndirizzoNonValidoException extends Exception {
    
    
}
