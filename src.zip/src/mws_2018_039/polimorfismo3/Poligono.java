package mws_2018_039.polimorfismo3;

public interface Poligono {
    public float dammiArea();
}
