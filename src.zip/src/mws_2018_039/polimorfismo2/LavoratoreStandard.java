package mws_2018_039.polimorfismo2;

public interface LavoratoreStandard {
    public void lavoraLun();
    public void lavoraMar();
    public void lavoraMer();
    public void lavoraGio();
    public void lavoraVen();
}
