package mws_2018_039.polimorfismo2;

public class Impiegato implements LavoratoreStandard{

    @Override
    public void lavoraLun() {
    }

    @Override
    public void lavoraMar() {
    }

    @Override
    public void lavoraMer() {
    }

    @Override
    public void lavoraGio() {
    }

    @Override
    public void lavoraVen() {
    }
    
}
