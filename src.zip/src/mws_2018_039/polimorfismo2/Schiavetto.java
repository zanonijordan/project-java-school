package mws_2018_039.polimorfismo2;

public class Schiavetto implements LavoratoreStandard, LavoratoreFestivo{

    @Override
    public void lavoraLun() {
    }

    @Override
    public void lavoraMar() {
    }

    @Override
    public void lavoraMer() {
    }

    @Override
    public void lavoraGio() {
    }

    @Override
    public void lavoraVen() {
    }

    @Override
    public void lavoraSab() {
    }

    @Override
    public void lavoraDom() {
    }
    
}
