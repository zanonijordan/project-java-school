package mws_2018_039.polimorfismo2;

public class Consulente implements LavoratoreFestivo {

    @Override
    public void lavoraSab() {
    }

    @Override
    public void lavoraDom() {
    }
    
}
