package mws_2018_039.polimorfismo2;

public interface LavoratoreFestivo {
    public void lavoraSab();
    public void lavoraDom();
}
