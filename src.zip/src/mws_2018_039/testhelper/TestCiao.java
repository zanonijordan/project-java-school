package mws_2018_039.testhelper;

public class TestCiao {
    public static void main(String[] args) {
        StudentiHelper.getInstance().deleteStudente(44);
    }
}
