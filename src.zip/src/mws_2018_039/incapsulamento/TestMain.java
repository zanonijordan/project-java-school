package mws_2018_039.incapsulamento;

public class TestMain {
    public static void main(String[] args) {
        
        Autovettura macchina1 = new Autovettura();
        System.out.println("marca: " + macchina1.getMarca());
        //macchina1.setMarca = "FIAT";
    }
}
