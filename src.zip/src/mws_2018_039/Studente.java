package mws_2018_039;

public class Studente {
    public static String nome;
    public static String cognome;
    public static String matricola;
    public static int anno;
    public static int eta;
    public static float saldo;
}
