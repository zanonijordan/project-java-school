package mws_2018_039.testistanze2;

public class Studente {
    public static int MAX_BOCCIATURE = 9;
    
    public String nome      ;
    public String cognome   ;
    public String matricola ;
    public int anno         ;
    
}
