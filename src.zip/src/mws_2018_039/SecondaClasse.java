package mws_2018_039;

public class SecondaClasse {
    
}
