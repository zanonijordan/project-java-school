package mws_2018_039.testexception;

public class DestinatarioSbagliatoException extends Exception{
    
}
