package mws_2018_039.testprimitive;

public class TestContronto3 {
    public static void main(String[] args) {
        Scrivania s1 = new Scrivania();
        Scrivania s2 = new Scrivania();
        
        
        s1.equals(s2);
        s1.compareTo( s2 );
        
    }
}
