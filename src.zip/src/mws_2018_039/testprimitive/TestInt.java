package mws_2018_039.testprimitive;

public class TestInt {
    public static void main(String[] args) {
        Integer i1 = 43;
        
        Integer i2 = new Integer( "33" );
        Double d = Double.valueOf("3");
        
    }
}
