package mws_2018_039.testscope;

public class Main {
    public static void main(String[] args) {
        Ciao c = new Ciao();
        c.nome    = "Lele";
        c.cognome = "Rizzo";
        c.stampaNome();
        c.stampa2("Ciao");
        c.stampaNome();
    }
}
