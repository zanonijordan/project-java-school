package mws_2018_039.testereditarieta;

public class Barca extends Veicolo {
    public Integer lunghezza;
    public Integer numeroMotori;
    public Integer numeroVele;
    
    public void attracca(){
        System.out.println("...accosto alla banchina del porto..");
    }
}
