package mws_2018_039.testereditarieta;

public class Veicolo {
    public static final int MAX_ANNI = 50;
    
    public String marca;
    public String modello;
    String telaio;
    public Integer lunghezza;

    public void accelera(){
        System.out.println("vado più veloce....");
    }
}
