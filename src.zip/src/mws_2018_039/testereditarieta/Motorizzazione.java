package mws_2018_039.testereditarieta;

public class Motorizzazione {
    public void immatricola( Veicolo v, String matricola ){
        
    }
}
