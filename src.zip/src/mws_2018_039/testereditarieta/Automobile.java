package mws_2018_039.testereditarieta;

public class Automobile extends Veicolo {
    public int pressioneGomme;
    
    public void faiIlPieno(){
        System.out.println("....faccio il pieno!!");
    }
}
